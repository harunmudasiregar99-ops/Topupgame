require("dotenv").config();
const express = require("express");
const midtransClient = require("midtrans-client");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

let snap = new midtransClient.Snap({
  isProduction: false,
  serverKey: process.env.MIDTRANS_SERVER_KEY
});

app.post("/pay", async (req, res) => {
  let order_id = "ORDER-" + Date.now();

  let parameter = {
    transaction_details: {
      order_id,
      gross_amount: req.body.nominal
    }
  };

  let trx = await snap.createTransaction(parameter);
  res.json({ token: trx.token });
});

app.listen(3000, () => console.log("Server jalan"));
